﻿Public Class Form2

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click
        felsvar()
    End Sub

    Private Sub PictureBox2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox2.Click
        felsvar()
    End Sub

    Private Sub PictureBox3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox3.Click
        rättsvar()
    End Sub

    Private Sub PictureBox4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox4.Click
        felsvar()
    End Sub

    Private Sub rättsvar()

        MsgBox("Bra jobbat!!!!!!???")
        Me.Hide()
        Form3.Show()

    End Sub

    Private Sub felsvar()

        MsgBox("hahahaha försök igen")

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Label1.ForeColor = Color.Black Then
            Label1.ForeColor = Color.Red
        ElseIf Label1.ForeColor = Color.Red Then
            Label1.ForeColor = Color.Blue
        ElseIf Label1.ForeColor = Color.Blue Then
            Label1.ForeColor = Color.Pink
        ElseIf Label1.ForeColor = Color.Pink Then
            Label1.ForeColor = Color.Yellow
        ElseIf Label1.ForeColor = Color.Yellow Then
            Label1.ForeColor = Color.Green
        ElseIf Label1.ForeColor = Color.Green Then
            Label1.ForeColor = Color.Aquamarine
        ElseIf Label1.ForeColor = Color.Aquamarine Then
            Label1.ForeColor = Color.Magenta
        ElseIf Label1.ForeColor = Color.Magenta Then
            Label1.ForeColor = Color.Black
        End If
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick

        If Label1.Visible = True Then
            Label1.Visible = False
        ElseIf Label1.Visible = False Then
            Label1.Visible = True
        End If

    End Sub

    Private Sub Timer3_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer3.Tick
        If Label2.ForeColor = Color.Black Then
            Label2.ForeColor = Color.Red
        ElseIf Label2.ForeColor = Color.Red Then
            Label2.ForeColor = Color.Blue
        ElseIf Label2.ForeColor = Color.Blue Then
            Label2.ForeColor = Color.Pink
        ElseIf Label2.ForeColor = Color.Pink Then
            Label2.ForeColor = Color.Yellow
        ElseIf Label2.ForeColor = Color.Yellow Then
            Label2.ForeColor = Color.Green
        ElseIf Label2.ForeColor = Color.Green Then
            Label2.ForeColor = Color.Aquamarine
        ElseIf Label2.ForeColor = Color.Aquamarine Then
            Label2.ForeColor = Color.Magenta
        ElseIf Label2.ForeColor = Color.Magenta Then
            Label2.ForeColor = Color.Black
        End If
    End Sub

    Private Sub Timer4_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer4.Tick
        If Label2.Visible = True Then
            Label2.Visible = False
        ElseIf Label2.Visible = False Then
            Label2.Visible = True
        End If
    End Sub
End Class